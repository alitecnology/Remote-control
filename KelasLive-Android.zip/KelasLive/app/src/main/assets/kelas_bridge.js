(function () {
  if (window.__ksInit || !window.KelasAndroid) return;
  window.__ksInit = true;

  /* 1. "program kendali" palsu: ws://127.0.0.1:8765 diarahkan ke layanan aksesibilitas di aplikasi */
  var RealWS = window.WebSocket;
  function FakeWS(url) {
    var self = this;
    self.url = url;
    self.readyState = 0;
    self.onopen = self.onmessage = self.onclose = self.onerror = null;
    function fire(name, ev) {
      var f = self['on' + name];
      if (f) { try { f.call(self, ev); } catch (e) {} }
    }
    setTimeout(function () {
      if (!KelasAndroid.isControlEnabled()) {
        self.readyState = 3;
        fire('close', { code: 1006 });
        return;
      }
      self.readyState = 1;
      fire('open', {});
      self._t = setInterval(function () {
        if (!KelasAndroid.isControlEnabled()) self.close();
      }, 1000);
    }, 50);
    self.send = function (d) {
      if (self.readyState !== 1) return;
      var m;
      try { m = JSON.parse(d); } catch (e) { return; }
      if (m.t === 'auth') {
        setTimeout(function () {
          fire('message', { data: JSON.stringify({ t: 'auth', ok: true }) });
        }, 0);
        return;
      }
      KelasAndroid.ctl(String(d));
    };
    self.close = function () {
      if (self.readyState === 3) return;
      self.readyState = 3;
      clearInterval(self._t);
      fire('close', { code: 1000 });
    };
  }
  function WS(u, p) {
    if (String(u).indexOf('127.0.0.1:8765') >= 0) return new FakeWS(u);
    return p === undefined ? new RealWS(u) : new RealWS(u, p);
  }
  WS.prototype = RealWS.prototype;
  WS.CONNECTING = 0; WS.OPEN = 1; WS.CLOSING = 2; WS.CLOSED = 3;
  window.WebSocket = WS;

  /* 2. berbagi layar: getDisplayMedia diisi tangkapan layar dari aplikasi */
  var cv = null, cx = null, last = null, track = null, tmr = null, pend = null;
  function cleanup() { clearInterval(tmr); tmr = null; }

  if (navigator.mediaDevices) {
    navigator.mediaDevices.getDisplayMedia = function () {
      return new Promise(function (res, rej) {
        pend = { res: res, rej: rej };
        KelasAndroid.startScreen();
      });
    };
  }

  window.__ks_result = function (ok, w, h) {
    var p = pend; pend = null;
    if (!p) return;
    if (!ok) {
      var e = new Error('Permission denied');
      e.name = 'NotAllowedError';
      p.rej(e);
      return;
    }
    cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    cx = cv.getContext('2d');
    cx.fillStyle = '#000';
    cx.fillRect(0, 0, w, h);
    var st = cv.captureStream(15);
    track = st.getVideoTracks()[0];
    try { track.contentHint = 'detail'; } catch (e) {}
    var origStop = track.stop.bind(track);
    track.stop = function () {
      origStop();
      cleanup();
      try { KelasAndroid.stopScreen(); } catch (e) {}
    };
    tmr = setInterval(function () {
      if (last && cx) cx.drawImage(last, 0, 0, cv.width, cv.height);
    }, 500);
    p.res(st);
  };

  /* Frame diambil sebagai JPEG biner dari aplikasi (tanpa base64 / string besar). */
  window.__ks_frame = function () {
    function done() { try { KelasAndroid.frameDone(); } catch (e) {} }
    fetch(location.origin + '/__frame?' + Date.now(), { cache: 'no-store' })
      .then(function (r) { if (!r.ok) throw 0; return r.blob(); })
      .then(function (b) {
        var u = URL.createObjectURL(b);
        var im = new Image();
        im.onload = function () {
          URL.revokeObjectURL(u);
          last = im;
          if (cx) cx.drawImage(im, 0, 0, cv.width, cv.height);
          done();
        };
        im.onerror = function () { URL.revokeObjectURL(u); done(); };
        im.src = u;
      })
      .catch(done);
  };

  window.__ks_ended = function () {
    cleanup();
    if (track) { try { track.dispatchEvent(new Event('ended')); } catch (e) {} }
  };
})();
