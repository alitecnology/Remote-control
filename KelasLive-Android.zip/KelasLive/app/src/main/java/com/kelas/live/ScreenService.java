package com.kelas.live;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;

/**
 * Menangkap layar (MediaProjection) dan menyediakan frame JPEG untuk halaman web.
 *
 * Desain hemat memori (penting untuk HP RAM 3GB):
 *  - Bitmap, Canvas, dan buffer JPEG dibuat SEKALI lalu dipakai ulang setiap frame
 *    (kode lama membuat 2 Bitmap + 1 stream + 1 string base64 baru tiap frame).
 *  - JPEG dikirim sebagai data biner lewat permintaan "/__frame" (tanpa base64,
 *    tanpa string raksasa lewat evaluateJavascript).
 *  - Hanya 1 frame yang "dalam perjalanan"; frame terbaru disimpan sebagai Image
 *    tertunda (bukan di-encode berulang), jadi tidak ada antrean yang menumpuk.
 */
public class ScreenService extends Service {

    public interface Listener {
        void onStarted(int w, int h);

        /** Ada frame baru siap diambil halaman web lewat /__frame. */
        void onFrame();

        void onStopped();
    }

    public static volatile Listener listener;

    private static final String CHANNEL = "kelas_screen";
    private static volatile int jpegQuality = 82;       // 40..95, diatur guru lewat halaman
    private static volatile long baseInterval = 83;     // ~12 frame/detik
    private static volatile long adaptInterval = 0;     // otomatis naik bila HP murid kewalahan

    /** Dipanggil dari halaman (guru meminta kualitas). level 1=hemat, 2=tajam, 3=maksimal. */
    public static void setLevel(int level) {
        if (level <= 1) { jpegQuality = 62; baseInterval = 125; }
        else if (level >= 3) { jpegQuality = 92; baseInterval = 66; }
        else { jpegQuality = 82; baseInterval = 83; }
        adaptInterval = 0;
    }
    private static final long STUCK_MS = 2000;         // halaman tidak membalas -> lanjut saja

    private static final Object LOCK = new Object();
    private static ScreenService inst;
    private static boolean busy = false;               // dijaga LOCK
    private static long sentAt = 0;                    // dijaga LOCK
    private static byte[] jpegBuf = null;              // dijaga LOCK
    private static int jpegLen = 0;                    // dijaga LOCK

    /** Dipakai MainActivity untuk menjawab permintaan /__frame. */
    public static InputStream frameStream() {
        synchronized (LOCK) {
            if (jpegBuf == null || jpegLen == 0) return null;
            return new ByteArrayInputStream(jpegBuf, 0, jpegLen);
        }
    }

    /** Halaman web selesai menggambar frame sebelumnya. */
    public static void frameDone() {
        ScreenService s;
        synchronized (LOCK) {
            busy = false;
            s = inst;
        }
        if (s != null && s.handler != null) s.handler.post(s.pumpTask);
    }

    public static void stopCapture() {
        ScreenService s = inst;
        if (s != null) s.stopSelf();
    }

    // Stream JPEG yang bisa dipakai ulang (reset() tidak melepas array dalamnya).
    private static class ReusableStream extends ByteArrayOutputStream {
        ReusableStream() {
            super(256 * 1024);
        }

        byte[] array() {
            return buf;
        }
    }

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler handler;
    private boolean started = false;
    private volatile boolean stopped = false;
    private int w, h;

    // dipakai hanya di thread handler
    private Image pending;
    private long lastSent = 0;
    private Bitmap bmp, crop;
    private Canvas cropCanvas;
    private Rect cropRect;
    private final ReusableStream bos = new ReusableStream();

    private final Runnable pumpTask = new Runnable() {
        @Override
        public void run() {
            pump();
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        inst = this;
        goForeground();

        int code = intent.getIntExtra("code", 0);
        Intent data = intent.getParcelableExtra("data");
        if (data == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            thread = new HandlerThread("kelas-screen");
            thread.start();
            handler = new Handler(thread.getLooper());

            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopSelf();
                }
            }, handler);

            DisplayMetrics dm = new DisplayMetrics();
            ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
            // Resolusi asli layar murid apa adanya (tidak diperkecil).
            w = dm.widthPixels;
            h = dm.heightPixels;
            w -= w % 2;
            h -= h % 2;

            synchronized (LOCK) {
                busy = false;
                jpegBuf = null;
                jpegLen = 0;
            }

            // 3 buffer: 1 sedang ditulis sistem, 1 kita pegang (tertunda), 1 cadangan.
            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3);
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader r) {
                    onAvailable(r);
                }
            }, handler);

            display = projection.createVirtualDisplay("kelas-live", w, h, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, handler);

            started = true;
            Listener l = listener;
            if (l != null) l.onStarted(w, h);
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    /** Frame baru dari layar: simpan yang terbaru saja, buang yang lama. */
    private void onAvailable(ImageReader r) {
        if (stopped) return;
        Image img;
        try {
            img = r.acquireLatestImage();
        } catch (Exception e) {
            return;
        }
        if (img == null) return;
        if (pending != null) pending.close();
        pending = img;
        pump();
    }

    /** Encode frame tertunda bila halaman siap dan jeda minimum sudah lewat. */
    private void pump() {
        if (stopped || pending == null) return;
        long now = SystemClock.uptimeMillis();

        synchronized (LOCK) {
            if (busy && now - sentAt < STUCK_MS) return; // tunggu frameDone()
        }

        long wait = lastSent + Math.max(baseInterval, adaptInterval) - now;
        if (wait > 0) {
            handler.removeCallbacks(pumpTask);
            handler.postDelayed(pumpTask, wait);
            return;
        }

        Image img = pending;
        pending = null;
        boolean ok = false;
        long t0 = SystemClock.uptimeMillis();
        try {
            encode(img);
            ok = true;
        } catch (Throwable ignored) {
        } finally {
            img.close();
        }
        lastSent = now;
        // Pelindung HP lama: kalau encode lambat, jarak antar frame otomatis dilonggarkan.
        long took = SystemClock.uptimeMillis() - t0;
        if (took > baseInterval * 0.7) adaptInterval = Math.min(400, Math.max(adaptInterval, (long) (took * 1.6)));
        else if (adaptInterval > 0 && took < baseInterval * 0.4) adaptInterval = Math.max(0, adaptInterval - 10);
        if (!ok) return;

        Listener l = listener;
        synchronized (LOCK) {
            jpegBuf = bos.array();
            jpegLen = bos.size();
            busy = (l != null);
            sentAt = now;
        }
        if (l != null) l.onFrame();
    }

    private void encode(Image img) {
        Image.Plane plane = img.getPlanes()[0];
        ByteBuffer buf = plane.getBuffer();
        int bw = plane.getRowStride() / plane.getPixelStride();

        if (bmp == null || bmp.getWidth() != bw) {
            if (bmp != null) bmp.recycle();
            bmp = Bitmap.createBitmap(bw, h, Bitmap.Config.ARGB_8888);
            if (crop != null) {
                crop.recycle();
                crop = null;
            }
        }
        buf.rewind();
        bmp.copyPixelsFromBuffer(buf);

        Bitmap src = bmp;
        if (bw != w) {
            // Ada padding di sisi kanan: salin area w x h ke bitmap tetap (tanpa alokasi baru).
            if (crop == null) {
                crop = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                cropCanvas = new Canvas(crop);
                cropRect = new Rect(0, 0, w, h);
            }
            cropCanvas.drawBitmap(bmp, cropRect, cropRect, null);
            src = crop;
        }

        bos.reset();
        src.compress(Bitmap.CompressFormat.JPEG, jpegQuality, bos);
    }

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Kelas Live",
                    NotificationManager.IMPORTANCE_LOW));
            nb = new Notification.Builder(this, CHANNEL);
        } else {
            nb = new Notification.Builder(this);
        }
        Notification n = nb.setContentTitle(getString(R.string.notif_title))
                .setContentText(getString(R.string.notif_text))
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
    }

    @Override
    public void onDestroy() {
        stopped = true;
        try {
            if (display != null) display.release();
        } catch (Exception ignored) {
        }
        try {
            if (projection != null) projection.stop();
        } catch (Exception ignored) {
        }

        // Bersihkan sumber daya milik thread handler di thread itu sendiri, lalu matikan thread.
        final Handler hd = handler;
        final HandlerThread th = thread;
        if (hd != null && th != null) {
            hd.removeCallbacksAndMessages(null);
            hd.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (pending != null) pending.close();
                    } catch (Exception ignored) {
                    }
                    pending = null;
                    try {
                        if (reader != null) reader.close();
                    } catch (Exception ignored) {
                    }
                    if (bmp != null) bmp.recycle();
                    if (crop != null) crop.recycle();
                    bmp = crop = null;
                    th.quitSafely();
                }
            });
        } else {
            try {
                if (reader != null) reader.close();
            } catch (Exception ignored) {
            }
            if (th != null) th.quitSafely();
        }

        synchronized (LOCK) {
            busy = false;
            jpegBuf = null;
            jpegLen = 0;
            if (inst == this) inst = null;
        }
        Listener l = listener;
        if (started && l != null) l.onStopped();
        super.onDestroy();
    }
}
