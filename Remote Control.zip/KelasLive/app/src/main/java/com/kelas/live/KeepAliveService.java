package com.kelas.live;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Menjaga aplikasi tetap hidup saat murid keluar dari aplikasi
 * (notifikasi tetap tampil, kamera/mikrofon tetap boleh berjalan).
 */
public class KeepAliveService extends Service {

    private static final String CHANNEL = "kelas_bg";
    private PowerManager.WakeLock lock;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Kelas Live (latar belakang)",
                    NotificationManager.IMPORTANCE_LOW));
            nb = new Notification.Builder(this, CHANNEL);
        } else {
            nb = new Notification.Builder(this);
        }
        Notification n = nb.setContentTitle(getString(R.string.notif_title))
                .setContentText(getString(R.string.notif_bg_text))
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                        | ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(2, n);
            }
        } catch (Exception e) {
            try {
                startForeground(2, n);
            } catch (Exception e2) {
                stopSelf();
                return START_NOT_STICKY;
            }
        }
        try {
            if (lock == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kelas:bg");
                lock.acquire(12 * 60 * 60 * 1000L);
            }
        } catch (Exception ignored) {
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            if (lock != null && lock.isHeld()) lock.release();
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
