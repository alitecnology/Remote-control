package com.kelas.live;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

/**
 * Menangkap layar (MediaProjection) dan mengirim potongan gambar JPEG
 * ke halaman web lewat Listener. Halaman web mengubahnya menjadi video.
 */
public class ScreenService extends Service {

    public interface Listener {
        void onStarted(int w, int h);

        void onFrame(String jpegBase64);

        void onStopped();
    }

    public static volatile Listener listener;

    private static ScreenService inst;
    private static final Object LOCK = new Object();
    private static boolean busy = false;
    private static String queued = null;

    private static final String CHANNEL = "kelas_screen";

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private long lastSent = 0;
    private int w, h;
    private boolean started = false;

    public static void frameDone() {
        String q;
        synchronized (LOCK) {
            busy = false;
            q = queued;
            queued = null;
            if (q != null) busy = true;
        }
        Listener l = listener;
        if (q != null && l != null) l.onFrame(q);
    }

    public static void stopCapture() {
        ScreenService s = inst;
        if (s != null) s.stopSelf();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        inst = this;
        goForeground();

        int code = intent.getIntExtra("code", 0);
        Intent data = intent.getParcelableExtra("data");
        if (data == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            thread = new HandlerThread("kelas-screen");
            thread.start();
            Handler handler = new Handler(thread.getLooper());

            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopSelf();
                }
            }, handler);

            DisplayMetrics dm = new DisplayMetrics();
            ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
            int rw = dm.widthPixels, rh = dm.heightPixels;
            w = Math.min(720, rw);
            h = Math.round((float) rh * w / rw);
            w -= w % 2;
            h -= h % 2;

            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader r) {
                    grab(r);
                }
            }, handler);

            display = projection.createVirtualDisplay("kelas-live", w, h, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, handler);

            started = true;
            Listener l = listener;
            if (l != null) l.onStarted(w, h);
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void grab(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            long now = System.currentTimeMillis();
            if (now - lastSent < 120) return;

            Image.Plane plane = img.getPlanes()[0];
            ByteBuffer buf = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            int bw = rowStride / pixelStride;

            Bitmap bmp = Bitmap.createBitmap(bw, h, Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buf);
            Bitmap crop = (bw == w) ? bmp : Bitmap.createBitmap(bmp, 0, 0, w, h);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            crop.compress(Bitmap.CompressFormat.JPEG, 55, bos);
            String b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            if (crop != bmp) crop.recycle();
            bmp.recycle();
            lastSent = now;

            boolean send;
            synchronized (LOCK) {
                if (busy) {
                    queued = b64;
                    send = false;
                } else {
                    busy = true;
                    send = true;
                }
            }
            Listener l = listener;
            if (send && l != null) l.onFrame(b64);
        } catch (Exception ignored) {
        } finally {
            if (img != null) img.close();
        }
    }

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Kelas Live",
                    NotificationManager.IMPORTANCE_LOW));
            nb = new Notification.Builder(this, CHANNEL);
        } else {
            nb = new Notification.Builder(this);
        }
        Notification n = nb.setContentTitle(getString(R.string.notif_title))
                .setContentText(getString(R.string.notif_text))
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
    }

    @Override
    public void onDestroy() {
        try {
            if (display != null) display.release();
        } catch (Exception ignored) {
        }
        try {
            if (reader != null) reader.close();
        } catch (Exception ignored) {
        }
        try {
            if (projection != null) projection.stop();
        } catch (Exception ignored) {
        }
        if (thread != null) thread.quitSafely();
        synchronized (LOCK) {
            busy = false;
            queued = null;
        }
        if (inst == this) inst = null;
        Listener l = listener;
        if (started && l != null) l.onStopped();
        super.onDestroy();
    }
}
