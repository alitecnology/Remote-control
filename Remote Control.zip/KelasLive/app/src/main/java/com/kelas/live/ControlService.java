package com.kelas.live;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Menjalankan perintah kendali dari guru (klik, geser, gulir, tombol, teks)
 * di perangkat murid. Aktif setelah murid menyalakannya sekali di
 * Pengaturan > Aksesibilitas.
 */
public class ControlService extends AccessibilityService {

    private static ControlService inst;

    private final Handler main = new Handler(Looper.getMainLooper());
    private float curX = 0.5f, curY = 0.5f;
    private boolean dragging = false;
    private long downTime = 0;
    private final List<float[]> path = new ArrayList<>();

    public static boolean isRunning() {
        return inst != null;
    }

    public static void handle(final String json) {
        if (Build.VERSION.SDK_INT < 24) return;
        final ControlService s = inst;
        if (s == null) return;
        s.main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    s.act(new JSONObject(json));
                } catch (Exception ignored) {
                }
            }
        });
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (inst == this) inst = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        if (inst == this) inst = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    // ---------- util ----------

    private int[] size() {
        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    private static float clamp01(double v) {
        if (v < 0) return 0f;
        if (v > 1) return 1f;
        return (float) v;
    }

    private void play(GestureDescription.StrokeDescription... strokes) {
        try {
            GestureDescription.Builder b = new GestureDescription.Builder();
            for (GestureDescription.StrokeDescription s : strokes) b.addStroke(s);
            dispatchGesture(b.build(), null, null);
        } catch (Exception ignored) {
        }
    }

    private GestureDescription.StrokeDescription tapStroke(float fx, float fy, long start, long dur) {
        int[] sz = size();
        Path p = new Path();
        p.moveTo(fx * sz[0], fy * sz[1]);
        return new GestureDescription.StrokeDescription(p, start, dur);
    }

    private void swipe(float x1, float y1, float x2, float y2, long dur) {
        int[] sz = size();
        Path p = new Path();
        p.moveTo(clamp01(x1) * sz[0], clamp01(y1) * sz[1]);
        p.lineTo(clamp01(x2) * sz[0], clamp01(y2) * sz[1]);
        play(new GestureDescription.StrokeDescription(p, 0, Math.max(60, dur)));
    }

    // ---------- perintah ----------

    private void act(JSONObject m) {
        String t = m.optString("t", "");
        if (m.has("x") && m.has("y")) {
            curX = clamp01(m.optDouble("x", curX));
            curY = clamp01(m.optDouble("y", curY));
            if (dragging) path.add(new float[]{curX, curY});
        }
        boolean right = "right".equals(m.optString("b", "left"));

        switch (t) {
            case "move":
                break;
            case "click":
                if (right) {
                    play(tapStroke(curX, curY, 0, 700));
                } else if (m.optInt("n", 1) == 2) {
                    play(tapStroke(curX, curY, 0, 40), tapStroke(curX, curY, 110, 40));
                } else {
                    play(tapStroke(curX, curY, 0, 50));
                }
                break;
            case "down":
                dragging = true;
                downTime = System.currentTimeMillis();
                path.clear();
                path.add(new float[]{curX, curY});
                break;
            case "up":
                if (dragging) {
                    dragging = false;
                    path.add(new float[]{curX, curY});
                    finishDrag();
                }
                break;
            case "scroll":
                scroll(m.optDouble("d", 0));
                break;
            case "key":
                key(m.optString("k", ""));
                break;
            case "text":
                appendText(m.optString("s", ""));
                break;
            default:
                break;
        }
    }

    private void finishDrag() {
        int[] sz = size();
        float[] a = path.get(0);
        float[] z = path.get(path.size() - 1);
        float dx = (z[0] - a[0]) * sz[0];
        float dy = (z[1] - a[1]) * sz[1];
        if (Math.sqrt(dx * dx + dy * dy) < 12 && path.size() < 3) {
            play(tapStroke(a[0], a[1], 0, 50));
            return;
        }
        Path p = new Path();
        p.moveTo(a[0] * sz[0], a[1] * sz[1]);
        for (int i = 1; i < path.size(); i++) {
            p.lineTo(path.get(i)[0] * sz[0], path.get(i)[1] * sz[1]);
        }
        long dur = Math.max(200, Math.min(System.currentTimeMillis() - downTime, 4000));
        play(new GestureDescription.StrokeDescription(p, 0, dur));
    }

    /** d > 0 = isi layar bergeser ke bawah (seperti roda mouse ke atas). */
    private void scroll(double d) {
        if (d == 0) return;
        float dist = (float) Math.min(0.6, Math.abs(d) * 0.06);
        float mid = 0.5f;
        if (d > 0) swipe(0.5f, mid - dist / 2, 0.5f, mid + dist / 2, 220);
        else swipe(0.5f, mid + dist / 2, 0.5f, mid - dist / 2, 220);
    }

    private void key(String k) {
        switch (k) {
            case "esc":
                performGlobalAction(GLOBAL_ACTION_BACK);
                break;
            case "win":
                performGlobalAction(GLOBAL_ACTION_HOME);
                break;
            case "tab":
                performGlobalAction(GLOBAL_ACTION_RECENTS);
                break;
            case "enter":
                pressEnter();
                break;
            case "backspace":
                backspace();
                break;
            case "space":
                appendText(" ");
                break;
            case "up":
                scroll(3);
                break;
            case "down":
                scroll(-3);
                break;
            case "pageup":
                scroll(8);
                break;
            case "pagedown":
                scroll(-8);
                break;
            case "left":
                swipe(0.3f, 0.5f, 0.7f, 0.5f, 220);
                break;
            case "right":
                swipe(0.7f, 0.5f, 0.3f, 0.5f, 220);
                break;
            default:
                break;
        }
    }

    // ---------- teks ----------

    private AccessibilityNodeInfo focusedInput() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        return root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
    }

    private static CharSequence currentText(AccessibilityNodeInfo n) {
        CharSequence c = n.getText();
        if (c == null) return "";
        if (Build.VERSION.SDK_INT >= 26 && n.isShowingHintText()) return "";
        return c;
    }

    private void setText(AccessibilityNodeInfo n, CharSequence text) {
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
    }

    private void appendText(String s) {
        if (s == null || s.isEmpty()) return;
        AccessibilityNodeInfo n = focusedInput();
        if (n == null) return;
        setText(n, currentText(n).toString() + s);
    }

    private void backspace() {
        AccessibilityNodeInfo n = focusedInput();
        if (n == null) return;
        String c = currentText(n).toString();
        if (c.isEmpty()) return;
        setText(n, c.substring(0, c.length() - 1));
    }

    private void pressEnter() {
        AccessibilityNodeInfo n = focusedInput();
        if (n == null) return;
        if (Build.VERSION.SDK_INT >= 30) {
            n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
        }
    }
}
